if(window.chread_tutorial_nextStep){
    window.chread_tutorial_nextStep();
    console.log("wah")
}